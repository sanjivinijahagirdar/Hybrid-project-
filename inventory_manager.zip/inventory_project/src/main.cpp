/*
 * main.cpp  –  Entry point for the Hybrid Inventory Manager
 *
 * Displays the menu, reads the user's choice, and dispatches
 * to the appropriate InventoryManager method.
 */

#include <iostream>
#include <limits>
#include <string>
#include "InventoryManager.h"

static const char *RESET  = "\033[0m";
static const char *BOLD   = "\033[1m";
static const char *CYAN   = "\033[36m";
static const char *YELLOW = "\033[33m";
static const char *RED    = "\033[31m";

static void printMenu()
{
    std::cout << BOLD << CYAN
              << "\n==============================\n"
              << "   Hybrid Inventory Manager  \n"
              << "==============================\n"
              << RESET
              << "  1) Add item\n"
              << "  2) View item\n"
              << "  3) Update item\n"
              << "  4) Delete item\n"
              << "  5) List all items\n"
              << "  6) Exit\n"
              << BOLD << CYAN
              << "==============================\n"
              << RESET
              << "Choice: ";
}

int main()
{
    InventoryManager mgr;

    while (true) {
        printMenu();

        std::string line;
        if (!std::getline(std::cin, line)) {
            /* EOF / piped input finished */
            std::cout << "\n";
            break;
        }

        if (line.empty()) continue;

        int choice = 0;
        try { choice = std::stoi(line); }
        catch (...) { choice = 0; }

        switch (choice) {
            case 1: mgr.addItem();     break;
            case 2: mgr.viewItem();    break;
            case 3: mgr.updateItem();  break;
            case 4: mgr.deleteItem();  break;
            case 5: mgr.listAllItems(); break;
            case 6:
                std::cout << YELLOW << "Goodbye!\n" << RESET;
                return 0;
            default:
                std::cout << RED
                          << "  Invalid choice – please enter 1–6.\n"
                          << RESET;
        }
    }
    return 0;
}
