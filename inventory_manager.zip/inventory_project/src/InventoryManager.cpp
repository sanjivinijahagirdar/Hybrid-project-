/*
 * InventoryManager.cpp  –  C++ layer for the Hybrid Inventory Manager
 *
 * Wraps the C backend (inventory.c) in a class.
 * Uses std::vector to hold a temporary snapshot of items and
 * std::sort to sort them before printing.
 */

#include "InventoryManager.h"

#include <algorithm>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>

/* ------------------------------------------------------------------ */
/*  ANSI colour helpers (gracefully degrade on non-ANSI terminals)    */
/* ------------------------------------------------------------------ */
static const char *RESET  = "\033[0m";
static const char *BOLD   = "\033[1m";
static const char *CYAN   = "\033[36m";
static const char *GREEN  = "\033[32m";
static const char *YELLOW = "\033[33m";
static const char *RED    = "\033[31m";

/* ------------------------------------------------------------------ */
/*  Input utilities                                                    */
/* ------------------------------------------------------------------ */

/*
 * Read a whole line then convert to int.
 * Re-prompts on bad input.
 */
static int prompt_int(const std::string &label)
{
    while (true) {
        std::cout << label;
        std::string line;
        if (!std::getline(std::cin, line)) return -1;
        std::istringstream ss(line);
        int v;
        char extra;
        if ((ss >> v) && !(ss >> extra))
            return v;
        std::cout << RED << "  Invalid input – please enter a whole number.\n"
                  << RESET;
    }
}

static float prompt_float(const std::string &label)
{
    while (true) {
        std::cout << label;
        std::string line;
        if (!std::getline(std::cin, line)) return -1.0f;
        std::istringstream ss(line);
        float v;
        char extra;
        if ((ss >> v) && !(ss >> extra))
            return v;
        std::cout << RED << "  Invalid input – please enter a number.\n"
                  << RESET;
    }
}

static std::string prompt_string(const std::string &label)
{
    while (true) {
        std::cout << label;
        std::string line;
        if (!std::getline(std::cin, line)) return "";
        if (!line.empty()) return line;
        std::cout << RED << "  Name must not be empty.\n" << RESET;
    }
}

/* ------------------------------------------------------------------ */
/*  InventoryManager public interface                                  */
/* ------------------------------------------------------------------ */

void InventoryManager::addItem()
{
    std::cout << BOLD << "\n-- Add Item --\n" << RESET;

    /* --- ID -------------------------------------------------------- */
    int id;
    while (true) {
        id = prompt_int("  Item ID (positive integer): ");
        if (id > 0) break;
        std::cout << RED << "  ID must be a positive integer.\n" << RESET;
    }

    /* --- Name ------------------------------------------------------ */
    std::string name = prompt_string("  Name: ");
    if (name.length() >= NAME_LEN) {
        name = name.substr(0, NAME_LEN - 1);
        std::cout << YELLOW << "  Name truncated to " << (NAME_LEN - 1)
                  << " characters.\n" << RESET;
    }

    /* --- Quantity -------------------------------------------------- */
    int qty;
    while (true) {
        qty = prompt_int("  Quantity (0 or more): ");
        if (qty >= 0) break;
        std::cout << RED << "  Quantity must be 0 or more.\n" << RESET;
    }

    /* --- Price ----------------------------------------------------- */
    float price;
    while (true) {
        price = prompt_float("  Price (0.00 or more): ");
        if (price >= 0.0f) break;
        std::cout << RED << "  Price must be 0 or more.\n" << RESET;
    }

    /* --- Build and store ------------------------------------------ */
    Item item;
    item.id         = id;
    item.quantity   = qty;
    item.price      = price;
    item.is_deleted = 0;
    std::strncpy(item.name, name.c_str(), NAME_LEN - 1);
    item.name[NAME_LEN - 1] = '\0';

    if (add_item(&item))
        std::cout << GREEN << "  Item " << id << " added successfully.\n" << RESET;
    else
        std::cout << RED
                  << "  Failed to add item (ID may already exist).\n"
                  << RESET;
}

void InventoryManager::viewItem()
{
    std::cout << BOLD << "\n-- View Item --\n" << RESET;

    int id;
    while (true) {
        id = prompt_int("  Item ID: ");
        if (id > 0) break;
        std::cout << RED << "  ID must be positive.\n" << RESET;
    }

    Item item;
    if (get_item(id, &item)) {
        printHeader();
        printRow(item);
        printFooter();
    } else {
        std::cout << RED << "  Item " << id
                  << " not found or has been deleted.\n" << RESET;
    }
}

void InventoryManager::updateItem()
{
    std::cout << BOLD << "\n-- Update Item --\n" << RESET;

    int id;
    while (true) {
        id = prompt_int("  Item ID to update: ");
        if (id > 0) break;
        std::cout << RED << "  ID must be positive.\n" << RESET;
    }

    /* Verify it exists first */
    Item existing;
    if (!get_item(id, &existing)) {
        std::cout << RED << "  Item " << id
                  << " not found or has been deleted.\n" << RESET;
        return;
    }

    std::cout << "  Current record:\n";
    printHeader();
    printRow(existing);
    printFooter();
    std::cout << "  Enter new values (leave blank = keep current value):\n";

    /* --- Name ------------------------------------------------------ */
    std::cout << "  New name [" << existing.name << "]: ";
    std::string nameInput;
    std::getline(std::cin, nameInput);
    if (nameInput.empty())
        nameInput = existing.name;
    if (nameInput.length() >= NAME_LEN)
        nameInput = nameInput.substr(0, NAME_LEN - 1);

    /* --- Quantity -------------------------------------------------- */
    int qty;
    while (true) {
        qty = prompt_int("  New quantity [" +
                         std::to_string(existing.quantity) + "]: ");
        if (qty >= 0) break;
        std::cout << RED << "  Quantity must be 0 or more.\n" << RESET;
    }

    /* --- Price ----------------------------------------------------- */
    float price;
    while (true) {
        price = prompt_float("  New price [" +
                             std::to_string(existing.price) + "]: ");
        if (price >= 0.0f) break;
        std::cout << RED << "  Price must be 0 or more.\n" << RESET;
    }

    Item updated;
    updated.id         = id;
    updated.quantity   = qty;
    updated.price      = price;
    updated.is_deleted = 0;
    std::strncpy(updated.name, nameInput.c_str(), NAME_LEN - 1);
    updated.name[NAME_LEN - 1] = '\0';

    if (update_item(id, &updated))
        std::cout << GREEN << "  Item " << id << " updated.\n" << RESET;
    else
        std::cout << RED << "  Update failed.\n" << RESET;
}

void InventoryManager::deleteItem()
{
    std::cout << BOLD << "\n-- Delete Item --\n" << RESET;

    int id;
    while (true) {
        id = prompt_int("  Item ID to delete: ");
        if (id > 0) break;
        std::cout << RED << "  ID must be positive.\n" << RESET;
    }

    if (delete_item(id))
        std::cout << GREEN << "  Item " << id << " deleted.\n" << RESET;
    else
        std::cout << RED
                  << "  Item " << id
                  << " not found or already deleted.\n" << RESET;
}

void InventoryManager::listAllItems()
{
    std::cout << BOLD << "\n-- All Items --\n" << RESET;

    /* Ask how the user wants to sort */
    std::cout << "  Sort by: (1) ID  (2) Name  [1]: ";
    std::string choice;
    std::getline(std::cin, choice);
    bool sortByName = (choice == "2");

    /* Load into a vector ------------------------------------------- */
    const int MAX = 4096;
    std::vector<Item> buf(MAX);
    int count = list_items(buf.data(), MAX);
    buf.resize(static_cast<std::size_t>(count));

    if (count == 0) {
        std::cout << YELLOW << "  No active items in inventory.\n" << RESET;
        return;
    }

    /* Sort using std::sort ----------------------------------------- */
    if (sortByName) {
        std::sort(buf.begin(), buf.end(), [](const Item &a, const Item &b) {
            return std::string(a.name) < std::string(b.name);
        });
    } else {
        std::sort(buf.begin(), buf.end(), [](const Item &a, const Item &b) {
            return a.id < b.id;
        });
    }

    printHeader();
    for (const Item &it : buf)
        printRow(it);
    printFooter();
    std::cout << GREEN << "  Total: " << count << " item(s)\n" << RESET;
}

/* ------------------------------------------------------------------ */
/*  Pretty-print helpers                                               */
/* ------------------------------------------------------------------ */

void InventoryManager::printHeader()
{
    std::cout << CYAN
              << std::left
              << std::setw(6)  << "ID"
              << std::setw(42) << "Name"
              << std::setw(10) << "Quantity"
              << "Price\n"
              << std::string(64, '-')
              << "\n" << RESET;
}

void InventoryManager::printRow(const Item &it)
{
    std::cout << std::left
              << std::setw(6)  << it.id
              << std::setw(42) << it.name
              << std::setw(10) << it.quantity
              << std::fixed << std::setprecision(2) << it.price
              << "\n";
}

void InventoryManager::printFooter()
{
    std::cout << CYAN << std::string(64, '-') << "\n" << RESET;
}
