/*
 * inventory.c  –  C backend for the Hybrid Inventory Manager
 *
 * Storage layout: flat binary file (inventory.dat).
 * Each record is sizeof(Item) bytes; record index == (id - 1)
 * so item with id=N lives at byte offset (N-1)*sizeof(Item).
 *
 * Rules:
 *   - IDs are assigned by the caller; duplicates are rejected.
 *   - Soft-delete: is_deleted = 1; those records are invisible to
 *     get_item / list_items but their slot is kept in the file.
 */

#include "inventory.h"

#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/*  Internal helpers                                                   */
/* ------------------------------------------------------------------ */

/*
 * Return the byte offset of record with the given id.
 * IDs are 1-based; record 0 does not exist.
 */
static long record_offset(int id)
{
    return (long)(id - 1) * (long)sizeof(Item);
}

/*
 * Read the raw record for `id` into *out (whether deleted or not).
 * Returns 1 if found (slot exists in file), 0 otherwise.
 */
static int raw_read(int id, Item *out)
{
    FILE *fp = fopen(DB_FILE, "rb");
    if (!fp) return 0;

    if (fseek(fp, record_offset(id), SEEK_SET) != 0) {
        fclose(fp);
        return 0;
    }
    int ok = (fread(out, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

/*
 * Write (overwrite) one record at the slot for item->id.
 * Creates / extends the file as needed.
 * Returns 1 on success, 0 on failure.
 */
static int raw_write(const Item *item)
{
    FILE *fp = fopen(DB_FILE, "r+b");   /* open existing for update */
    if (!fp)
        fp = fopen(DB_FILE, "w+b");     /* create if not present    */
    if (!fp) return 0;

    if (fseek(fp, record_offset(item->id), SEEK_SET) != 0) {
        fclose(fp);
        return 0;
    }
    int ok = (fwrite(item, sizeof(Item), 1, fp) == 1);
    fflush(fp);
    fclose(fp);
    return ok;
}

/* ------------------------------------------------------------------ */
/*  Public API                                                         */
/* ------------------------------------------------------------------ */

int add_item(const Item *item)
{
    if (!item || item->id <= 0) return 0;

    /* Reject duplicate IDs */
    Item existing;
    if (raw_read(item->id, &existing) && existing.id == item->id)
        return 0;   /* slot already occupied */

    return raw_write(item);
}

int get_item(int id, Item *out)
{
    if (id <= 0 || !out) return 0;

    Item tmp;
    if (!raw_read(id, &tmp)) return 0;
    if (tmp.id != id || tmp.is_deleted) return 0;

    *out = tmp;
    return 1;
}

int update_item(int id, const Item *updated)
{
    if (id <= 0 || !updated) return 0;

    Item existing;
    if (!raw_read(id, &existing)) return 0;
    if (existing.id != id || existing.is_deleted) return 0;

    /* Keep the same id and deleted-flag; only update the payload */
    Item tmp = *updated;
    tmp.id         = id;
    tmp.is_deleted = 0;

    return raw_write(&tmp);
}

int delete_item(int id)
{
    if (id <= 0) return 0;

    Item tmp;
    if (!raw_read(id, &tmp)) return 0;
    if (tmp.id != id || tmp.is_deleted) return 0;

    tmp.is_deleted = 1;
    return raw_write(&tmp);
}

int list_items(Item *buffer, int max_items)
{
    if (!buffer || max_items <= 0) return 0;

    FILE *fp = fopen(DB_FILE, "rb");
    if (!fp) return 0;

    int count = 0;
    Item tmp;
    while (count < max_items && fread(&tmp, sizeof(Item), 1, fp) == 1) {
        /* Skip uninitialized slots (id == 0) and soft-deleted records */
        if (tmp.id > 0 && !tmp.is_deleted)
            buffer[count++] = tmp;
    }
    fclose(fp);
    return count;
}
