# Hybrid Inventory Manager

A console-based inventory management system that uses **C** for binary file
persistence and **C++** for the interactive menu, STL collections, and sorting.

---

## Project Structure

```
inventory_project/
├── include/
│   ├── inventory.h          # Item struct + C function declarations
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend (fread/fwrite/fseek)
│   ├── InventoryManager.cpp # C++ class implementation
│   └── main.cpp             # Menu loop (entry point)
├── Makefile
├── CMakeLists.txt
└── README.md
```

---

## Build & Run

### Using Make (recommended)

```bash
# Build
make

# Run
./inventory_mgr

# Build and run in one step
make run

# Clean build artefacts + data file
make clean
```

### Using CMake

```bash
mkdir build_cmake && cd build_cmake
cmake ..
cmake --build .
./inventory_mgr
```

> **Requirements:** GCC ≥ 9 (or Clang ≥ 10) with C11 and C++17 support.

---

## Features

| Menu | Action |
|------|--------|
| 1    | Add a new item (unique positive ID required) |
| 2    | View a single item by ID |
| 3    | Update name / quantity / price of an existing item |
| 4    | Soft-delete an item (hidden from all views) |
| 5    | List all active items, sorted by ID or Name |
| 6    | Exit |

Data is stored in **`inventory.dat`** (binary, same directory).
The file persists between runs.

---

## Data Format

Each record is a fixed-size `Item` struct written with `fwrite`:

| Field        | Type      | Notes                      |
|--------------|-----------|----------------------------|
| `id`         | `int`     | Unique, 1-based, positive  |
| `name`       | `char[40]`| Non-empty string           |
| `quantity`   | `int`     | ≥ 0                        |
| `price`      | `float`   | ≥ 0.0                      |
| `is_deleted` | `int`     | 0 = active, 1 = deleted    |

Records are addressed directly via `fseek((id-1) * sizeof(Item))`.

---

## Test Cases

- **Persistence across restart**
  Added items 1 (Widget, qty 10, $2.50), 2 (Gadget, qty 5, $15.00), and
  3 (Doohickey, qty 0, $0.99). Exited (`6`), restarted, chose List all → all
  three items appeared correctly.

- **Update survives restart**
  Updated item 2's price from $15.00 to $12.99. Exited, restarted, viewed
  item 2 → new price $12.99 was shown.

- **Soft-delete hides item**
  Deleted item 1. Chose List all → only items 2 and 3 appeared. Chose
  View item with ID 1 → "not found or has been deleted" message shown.

- **Duplicate ID rejected**
  Tried adding a new item with ID 2 (already in use) → "Failed to add item
  (ID may already exist)" error shown; original record unchanged.

- **Input validation**
  Entered negative ID (-5) → re-prompted. Entered empty name → re-prompted.
  Entered negative quantity (-1) → re-prompted. All invalid inputs recovered
  gracefully without crashing.

---

## Design Notes

- **C backend** exposes exactly five functions (`add_item`, `get_item`,
  `update_item`, `delete_item`, `list_items`) declared in `inventory.h` with
  `extern "C"` guards so they link cleanly from C++.
- **C++ layer** (`InventoryManager`) uses `std::vector<Item>` to hold a
  temporary snapshot from `list_items` and `std::sort` (with lambdas) to
  sort by ID or Name before printing.
- **No dynamic memory** is used in the C layer; the C++ layer limits the
  snapshot to 4 096 items (easily adjusted via the `MAX` constant in
  `InventoryManager.cpp`).
