#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <vector>
#include "inventory.h"   /* Item struct + C function prototypes */

class InventoryManager {
public:
    void addItem();
    void viewItem();
    void updateItem();
    void deleteItem();
    void listAllItems();

private:
    void printHeader();
    void printRow(const Item &item);
    void printFooter();
};

#endif /* INVENTORY_MANAGER_H */
